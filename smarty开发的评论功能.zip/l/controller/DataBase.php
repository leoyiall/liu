 <?php
 /*
  *	by:leoyi
  * 2018-7-15
  * �Լ������װ��һ����ʽ�������ݿ�ķ�����
  * ��Ҫ����дԭ����smarty����ʱ�������ݿ��ʱ������õ���
  *
  * link: 330168885@qq.com
  * */
  	 require_once 'config.php';

	 class Database
	 {
		 private $name; //���ݿ����
		 private $where='';
		 private $order='';
		 private $limit='';
		 private $conn;
		 private $pre_tag;

		 public function __construct($msg) {
			 !empty($msg['pre_tag']) ? $this->pre_tag = $msg['pre_tag'] : ''; //��ǰ׺
			 !empty($msg['link']) ? $link = $msg['link'] : die("no config database link!");
			 !empty($msg['username']) ? $username = $msg['username'] : die("no config database username!");
			 !empty($msg['password']) ? $password = $msg['password'] : die("no config database password!");
			 !empty($msg['port']) ? $port = $msg['port'] : die("no config database port!");
			 !empty($msg['dbname']) ? $dbname = $msg['dbname'] : die("no config database dbname!");
			 !empty($msg['charset']) ? $charset = $msg['dbname'] : 'utf-8';

			 $conn = mysqli_connect($link.":".$port,$username,$password,$dbname) or die(" link database error!! ");
			 mysqli_query($conn,'set names '.$charset);
			 $this->conn = $conn;
		 }
		 //���������ݱ���
		 function name($name){
			 $this->name = $this->pre_tag.$name;
			 return $this;
		 }
		 //where����
		 function where($where)
		 {
			 $this->where = $where;
			 return $this;
		 }
		 //����
		 function order($order)
		 {
			 $this->order = $order;
			 return $this;
		 }

		 //��ѯ����
		 function limit($limit)
		 {
			 $this->limit = $limit;
			 return $this;
		 }
		 //����
		 function insert($data){
			 !empty($this->name) ? $name = $this->name : die("not choice db ");
			 if(empty($data)) die("not insert data! ");

			 $keys = '';
			 $vals = '';
			 foreach($data as $key => $val){
				 $keys .= $key.",";
				 $vals .= "'".$val."',";
			 }
			 $keys = rtrim($keys, ",");
			 $vals = rtrim($vals, ",");
			 $sql = "insert into $name($keys) values($vals)";
			 return $this->query($sql);
		 }
		 //��ѯ
		 function select(){
			 !empty($this->name)? $name = $this->name:die("not choice db ");
			 $where = !empty($this->where)? ' where '.$this->where:" ";
			 $order =!empty($this->order)?' order by '.$this->order: " ";
			 $limit = !empty($this->limit)? ' limit '.$this->limit: " ";

			 $sql = "select * from $name ".$where.$order.$limit;
			 $res = $this->query($sql);
		 	 $data= [];
			 while($row = mysqli_fetch_array($res,true)){
				 $data[] = $row;
			 }
			 return $data;
		 }

		 //ɾ��
		 function delete(){
			 !empty($this->name) ? $name = $this->name : die("not choice db ");
			 !empty($this->where) ? $where = $this->where : die("not choice condition ");

			 $sql = 'delete from '.$name.' where '.$where;
			 return $this->query($sql);
		 }

		 //�޸ı�
		 public function update($data){
			 !empty($this->name) ? $name = $this->name : die("not choice db ");
			 !empty($this->where) ? $where = $this->where : die("not choice condition ");

			 $condition = '';
			 foreach ($data as $key => $val)
			 {
				 $condition .= $key."=".$val.",";
			 }
			 $condition = rtrim($condition, ",");
			 if (empty($condition))
			 {
				 die("not update condition ");
			 }
			 $sql = "update $name set $condition where $where ";
			 return $this->query($sql);
		 }

		 //ִ��sql
		 public function query($sql){
			 !empty($this->conn) ? $conn = $this->conn : die("not link db ");
			 $result = mysqli_query($conn,$sql);
			 if(!$result){

				 die("query sql error !");
			 }else{
				 return $result;
			 }
		 }
	 }