<?php
	require 'D:\phpstudy\PHPTutorial\WWW\l\libs\smarty.class.php';
	require 'D:\phpstudy\PHPTutorial\WWW\l\controller\DataBase.php';
	$configs = require 'D:\phpstudy\PHPTutorial\WWW\l\controller\config.php';

	date_default_timezone_set("PRC");

	class Setup extends Smarty{
		public function __construct() {
			parent::__construct(); //�̳�smarty����Ĺ��캯������ֹ����

			$this->template_dir = './templates/';
			$this->compile_dir  = './templates_c/';
			$this->config_dir   = './configs/';
			$this->cache_dir    = './cache/';
			$this->assign('app_name', 'leoyi');
			$this->left_delimiter  = '<{';
			$this->right_delimiter = '}>';
		}
	}
	$smarty = new Setup;
	$db = new Database($configs['mysql']);

	//ֱ�ӹ��ú���
	function p($arr){
		echo "<pre>";
		print_r($arr);
		echo "</pre>";
	}
?>