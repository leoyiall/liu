<?php
	require_once "D:\phpstudy\PHPTutorial\WWW\l\controller\Base.php";

	class index {
		private $db;
		static public $tree = array();

		public function __construct($db) {
			$this->db = $db;
		}
		//��ҳ�������б�
		public function index(){
			$list = $this->db->name('comment')->order("id desc")->select();
			$list = $this->who($list);
			$list = self::getTree($list,0);
			return $list;
		}
		// ˭���͵�����
		public function who($list){
			$defined = array('uid'=>0,"image"=>"./public/static/header-img-comment_03.png"); //Ĭ��һ�������ߵ�ͷ��
			foreach($list as $key => $val){
				if($val['uid'] == $defined['uid']){
					$list[$key]['image'] = $defined['image'];
				}
			}
			return $list;
		}
		//��������
		public function add(){
			$comment = $_POST['comment'];
			if(empty($comment)) die("not comment!!");
			$uid = !empty($_POST['uid'])?$_POST['uid']:0;
			$nick = !empty($_POST['nick'])?$_POST['nick']:'����';
			$data = [
				'time'=>time(),
				'nick'=>$nick,
				'comment'=>$comment,
				'uid'=>$uid,
				'prise_num'=>0
			];
			if(isset($_POST['pid'])) $data['pid'] = $_POST['pid'];
			$res = $this->db->name("comment")->insert($data);
			$this->notice($res);
		}
		//��ʾ
		public function notice($res){
			if (!$res)
			{
				$msg = [
					'code' => 0,
					'res'  => 'fail to insert!'
				];
			}
			else
			{
				$msg = [
					'code' => 200,
					'res'  => 'success'
				];
			}

			return $msg;
		}
		//ɾ������
		public function deleteIt(){
			$u = $_POST['u'];
			$rid = $_POST['rid'];
//			if(empty($u))die("error!");
			if (empty($rid))
			{
				die("error!");
			}
			//�û���Ϣ��֤

			//ִ��ɾ��
			$res = $this->db->name("comment")->where("id=".$rid)->delete();
			$this->notice($res);
		}
		//����
		public function prise(){
			$u   = $_POST['u'];
			$pid = $_POST['pid'];
			$bool = $_POST['bool'];
			if (empty($pid))
			{
				die("error!");
			}
			//�û���Ϣ��֤

			//�����û���Ϣ
			$bool = $bool==1?"+":"-";
			$data = [
				'prise_num' => "prise_num".$bool."1"
			];
			$res  = $this->db->name("comment")->where("id=".$pid)->update($data);
			$this->notice($res);
		}
		//�㼶��
		static public function getTree($data, $pId)
		{

			$tree = '';
			foreach ($data as $k => $v)
			{
				if ($v['pid'] == $pId)
				{        //�����ҵ�����
					$v['children'] = self::getTree($data, $v['id']);
					$tree[] = $v;
				}
			}

			return $tree;
		}
	}


	//��Ӧ����

	$op = !empty($_REQUEST['op'])?$_REQUEST['op']:'';

	$obj = new index($db);
	$out = [
		'code'=>200,
		'res'=>''
	];
 	switch($op){
		case '1':
			$out = $obj->add();//����
			break;
		case '2':
			$obj->prise();//����
			break;
		case 3:
			$obj->deleteIt(); //ɾ��
			break;
	}

	$list = $obj->index();//�����б�

	$data = [
		'list'=>$list,
		'out'=>$out
	];
	$smarty->assign("data",$data);
	$smarty->display("index/index.tpl");
