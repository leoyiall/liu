<?php
	require('controller/index/index.php');