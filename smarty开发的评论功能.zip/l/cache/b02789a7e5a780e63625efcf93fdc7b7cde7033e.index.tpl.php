<?php
/* Smarty version 3.1.32, created on 2018-07-15 06:12:08
  from 'D:\phpstudy\PHPTutorial\WWW\l\templates\index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b4ae5b8201f29_78390739',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4189a449b98168f349ae8c2067e4574e6cf43f1c' => 
    array (
      0 => 'D:\\phpstudy\\PHPTutorial\\WWW\\l\\templates\\index.tpl',
      1 => 1531635127,
      2 => 'file',
    ),
  ),
  'cache_lifetime' => 3600,
),true)) {
function content_5b4ae5b8201f29_78390739 (Smarty_Internal_Template $_smarty_tpl) {
?><p>aax</p><?php }
}
