<?php
/* Smarty version 3.1.32, created on 2018-07-14 08:09:52
  from 'D:\phpstudy\PHPTutorial\WWW\l\templates\parent.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b49afd05b6765_24525827',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0d41aca0bdfc4efbad9de44c2cd808e0c5aad72c' => 
    array (
      0 => 'D:\\phpstudy\\PHPTutorial\\WWW\\l\\templates\\parent.tpl',
      1 => 1531555779,
      2 => 'file',
    ),
  ),
  'cache_lifetime' => 3600,
),true)) {
function content_5b49afd05b6765_24525827 (Smarty_Internal_Template $_smarty_tpl) {
?><html>
<head>
	<title>Title - </title>
</head>
</html><?php }
}
