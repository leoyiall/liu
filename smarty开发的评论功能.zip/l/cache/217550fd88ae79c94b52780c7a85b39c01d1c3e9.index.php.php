<?php
/* Smarty version 3.1.32, created on 2018-07-15 05:30:27
  from 'D:\phpstudy\PHPTutorial\WWW\l\templates\index.php' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b4adbf33f7524_63661578',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7ce20ae08388e630609158cb0f22af0b9aa7f675' => 
    array (
      0 => 'D:\\phpstudy\\PHPTutorial\\WWW\\l\\templates\\index.php',
      1 => 1531632626,
      2 => 'file',
    ),
  ),
  'cache_lifetime' => 3600,
),true)) {
function content_5b4adbf33f7524_63661578 (Smarty_Internal_Template $_smarty_tpl) {
?>a11<?php }
}
