<?php
/* Smarty version 3.1.32, created on 2018-07-14 11:16:08
  from 'D:\phpstudy\PHPTutorial\WWW\l\templates\debug.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b49db78f1a0d8_79495464',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0c04192d1f6868e90b450ca622de27281364be6d' => 
    array (
      0 => 'D:\\phpstudy\\PHPTutorial\\WWW\\l\\templates\\debug.tpl',
      1 => 1524581613,
      2 => 'file',
    ),
  ),
  'cache_lifetime' => 3600,
),true)) {
function content_5b49db78f1a0d8_79495464 (Smarty_Internal_Template $_smarty_tpl) {
?><script type="text/javascript">
        <br />
<b>Notice</b>:  Undefined index: display_mode in <b>D:\phpstudy\PHPTutorial\WWW\l\templates_c\0c04192d1f6868e90b450ca622de27281364be6d_0.file.debug.tpl.cache.php</b> on line <b>227</b><br />
<br />
<b>Notice</b>:  Trying to get property of non-object in <b>D:\phpstudy\PHPTutorial\WWW\l\templates_c\0c04192d1f6868e90b450ca622de27281364be6d_0.file.debug.tpl.cache.php</b> on line <b>227</b><br />
    _smarty_console = window.open("", "console__Smarty__", "width=1024,height=600,left=<br />
<b>Notice</b>:  Undefined index: offset in <b>D:\phpstudy\PHPTutorial\WWW\l\templates_c\0c04192d1f6868e90b450ca622de27281364be6d_0.file.debug.tpl.cache.php</b> on line <b>231</b><br />
<br />
<b>Notice</b>:  Trying to get property of non-object in <b>D:\phpstudy\PHPTutorial\WWW\l\templates_c\0c04192d1f6868e90b450ca622de27281364be6d_0.file.debug.tpl.cache.php</b> on line <b>231</b><br />
,top=<br />
<b>Notice</b>:  Undefined index: offset in <b>D:\phpstudy\PHPTutorial\WWW\l\templates_c\0c04192d1f6868e90b450ca622de27281364be6d_0.file.debug.tpl.cache.php</b> on line <b>232</b><br />
<br />
<b>Notice</b>:  Trying to get property of non-object in <b>D:\phpstudy\PHPTutorial\WWW\l\templates_c\0c04192d1f6868e90b450ca622de27281364be6d_0.file.debug.tpl.cache.php</b> on line <b>232</b><br />
,resizable,scrollbars=yes");
    _smarty_console.document.write("    <!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.1//EN\" \"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd\">\n    <html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\">\n    <head>\n        <title>Smarty Debug Console<\/title>\n        <style type=\"text/css\">\n            \n            body, h1, h2, h3, td, th, p {\n                font-family: sans-serif;\n                font-weight: normal;\n                font-size: 0.9em;\n                margin: 1px;\n                padding: 0;\n            }\n\n            h1 {\n                margin: 0;\n                text-align: left;\n                padding: 2px;\n                background-color: #f0c040;\n                color: black;\n                font-weight: bold;\n                font-size: 1.2em;\n            }\n\n            h2 {\n                background-color: #9B410E;\n                color: white;\n                text-align: left;\n                font-weight: bold;\n                padding: 2px;\n                border-top: 1px solid black;\n            }\n            h3 {\n                text-align: left;\n                font-weight: bold;\n                color: black;\n                font-size: 0.7em;\n                padding: 2px;\n            }\n\n            body {\n                background: black;\n            }\n\n            p, table, div {\n                background: #f0ead8;\n            }\n\n            p {\n                margin: 0;\n                font-style: italic;\n                text-align: center;\n            }\n\n            table {\n                width: 100%;\n            }\n\n            th, td {\n                font-family: monospace;\n                vertical-align: top;\n                text-align: left;\n            }\n\n            td {\n                color: green;\n            }\n\n            .odd {\n                background-color: #eeeeee;\n            }\n\n            .even {\n                background-color: #fafafa;\n            }\n\n            .exectime {\n                font-size: 0.8em;\n                font-style: italic;\n            }\n\n            #bold div {\n                color: black;\n                font-weight: bold;\n            }\n            #blue h3 {\n                color: blue;\n            }\n            #normal div {\n                color: black;\n                font-weight: normal;\n            }\n            #table_assigned_vars th {\n                color: blue;\n                font-weight: bold;\n            }\n\n            #table_config_vars th {\n                color: maroon;\n            }\n\n            \n        <\/style>\n    <\/head>\n    <body>\n\n    <h1>Smarty 3.1.32 Debug Console\n        -  <\/h1>\n\n    \n    <h2>assigned template variables<\/h2>\n\n    <table id=\"table_assigned_vars\">\n        <br />\n<b>Notice<\/b>:  Undefined index: assigned_vars in <b>D:\\phpstudy\\PHPTutorial\\WWW\\l\\templates_c\\0c04192d1f6868e90b450ca622de27281364be6d_0.file.debug.tpl.cache.php<\/b> on line <b>169<\/b><br />\n<br />\n<b>Notice<\/b>:  Trying to get property of non-object in <b>D:\\phpstudy\\PHPTutorial\\WWW\\l\\templates_c\\0c04192d1f6868e90b450ca622de27281364be6d_0.file.debug.tpl.cache.php<\/b> on line <b>169<\/b><br />\n    <\/table>\n\n    <h2>assigned config file variables<\/h2>\n\n    <table id=\"table_config_vars\">\n        <br />\n<b>Notice<\/b>:  Undefined index: config_vars in <b>D:\\phpstudy\\PHPTutorial\\WWW\\l\\templates_c\\0c04192d1f6868e90b450ca622de27281364be6d_0.file.debug.tpl.cache.php<\/b> on line <b>198<\/b><br />\n<br />\n<b>Notice<\/b>:  Trying to get property of non-object in <b>D:\\phpstudy\\PHPTutorial\\WWW\\l\\templates_c\\0c04192d1f6868e90b450ca622de27281364be6d_0.file.debug.tpl.cache.php<\/b> on line <b>198<\/b><br />\n\n    <\/table>\n    <\/body>\n    <\/html>\n");
    _smarty_console.document.close();
</script>
<?php }
}
