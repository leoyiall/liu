/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50553
Source Host           : localhost:3306
Source Database       : leoyi

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2018-07-16 14:33:41
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `l_comment`
-- ----------------------------
DROP TABLE IF EXISTS `l_comment`;
CREATE TABLE `l_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT '0' COMMENT '用户id',
  `comment` varchar(255) DEFAULT '' COMMENT '评论的内容',
  `prise_num` smallint(5) DEFAULT '0' COMMENT '赞的数量',
  `time` int(10) DEFAULT '0' COMMENT '发表时间',
  `nick` varchar(50) DEFAULT '' COMMENT '昵称',
  `pid` int(11) DEFAULT '0' COMMENT '父级id',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of l_comment
-- ----------------------------
INSERT INTO `l_comment` VALUES ('3', '0', 'test', '5', '1531661544', '琉忆', '0');
INSERT INTO `l_comment` VALUES ('7', '0', 'fdaf', '1', '1531661627', '琉忆', '0');
INSERT INTO `l_comment` VALUES ('9', '0', 'fdafad', '1', '1531712265', '阿帅', '0');
INSERT INTO `l_comment` VALUES ('10', '0', ' fdafdaf', '0', '1531712288', '阿帅', '0');
INSERT INTO `l_comment` VALUES ('12', '0', 'ccd', '0', '1531712545', '阿帅', '3');
INSERT INTO `l_comment` VALUES ('13', '0', ' 哈哈哈', '0', '1531714922', '阿帅', '1');
INSERT INTO `l_comment` VALUES ('21', '0', '211', '0', '1531722497', '阿帅', '10');
INSERT INTO `l_comment` VALUES ('22', '0', '!!', '0', '1531722500', '阿帅', '10');
